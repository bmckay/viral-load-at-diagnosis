# Roche PCR Study
# Clinical significance of qPCR data for Influenza
# Data Cleaning Script
# Author: Zane Billings, Brian Mckay
# Updated: 15 Jun 2020.
# This script will take the four raw data files, filter out all unique ID's
#  which are not positive results for Influenza A from the PCR data set,
#  and then left join all of the data together.
# This script will firstly compute aggregate scores based on reported and 
# diagnosed symptoms, create any necessary transformed values, and will remove 
# unneeded variables from the data to make it less cumbersome to use.


# Load libraries
# Provides read_csv for importing data as tbl.
if (require('readr')==FALSE) {install.packages('readr', repos="https://cran.rstudio.com"); require(readr)}
# Manipulation related to tbl objects.
# For plotting.
# Data wrangling and manipulation.
# Data cleaning and manipulation.
# For manipulation of factors. 
if (require('tidyverse')==FALSE) {install.packages('tidyverse', repos="https://cran.rstudio.com"); require(tidyverse)}
# Enables piping and pipe-friendly fcn aliases.
if (require('magrittr')==FALSE) {install.packages('magrittr', repos="https://cran.rstudio.com"); require(magrittr)}
# Used for making correlation plots.
if (require('ggcorrplot')==FALSE) {install.packages('ggcorrplot', repos="https://cran.rstudio.com"); require(ggcorrplot)}
# Needed for for the PairApply method.
if (require('DescTools')==FALSE) {install.packages('DescTools', repos="https://cran.rstudio.com"); require(DescTools)}

## This Function is used to compare correlations between symptoms
#----------------------------------------------------------------
# Check for correlation of symptoms. If two symptoms have r >= 0.9 or r <= -0.9
# one needs to be removed.
# This function removes correlated variables until there are none.
compare_cor <- function(df) {
  df <- as.data.frame(df)
  # Create Yule's Q matrix. 
  Q_mat <- PairApply(x = df, FUN = YuleQ, symmetric = TRUE)
  # Set the main diagonal to zero, so that the same column is not compared to itself.
  diag(Q_mat) <- 0
  
  # While an entry in the matrix is outside the tolerance range, continue 
  # comparing pairs of variables, removing a variable, and updated the matrix.
  while (TRUE %in% (Q_mat <= -0.9 | Q_mat >= 0.9)) {
    # Determine which pair of variables to compare. Index_max will contain two
    # entries, the row # and col # for the matrix where the first maximum entry
    # is located.
    Q_mat <- apply(Q_mat, c(1,2), abs)
    index_max <- which(Q_mat == max(Q_mat), arr.ind=TRUE)[1,1:2]
    
    # Compare the variables. If variable 1 has a VARIANCE greater than or equal to
    #  the variance of variable 2, discard variable 2. Else, discard variable 1.
    #  This ensures that we keep the variable with the mean closer to p = 0.5, 
    #  which theoretically encodes the most information.
    index_1 <- as.numeric(index_max[1])
    variable_name_1 <- rownames(Q_mat)[index_1]
    index_2 <- as.numeric(index_max[2])
    variable_name_2 <- colnames(Q_mat)[index_2]
    
    variable_1 <- df[ , variable_name_1]
    variable_2 <- df[ , variable_name_2]
    
    # Remove the correct variable based on above output.
    variance_1 <- mean(variable_1, na.rm = TRUE)*(1 - mean(variable_1, na.rm = TRUE))
    variance_2 <- mean(variable_2, na.rm = TRUE)*(1 - mean(variable_2, na.rm = TRUE))
    if (variance_1 >= variance_2) {
      temp <- colnames(df) != variable_name_2
      df <- df[ , temp]
    } else {
      temp <- colnames(df) != variable_name_1
      df <- df[ , temp]
    }
    
    # Update the Yule's Q matrix.
    Q_mat <- PairApply(x = df, FUN = YuleQ, symmetric = TRUE)
    # Set the main diagonal to zero, so that the same column is not compared to itself.
    diag(Q_mat) <- 0
    
    # Option to make plots of steps. If you want to make plots, uncomment this.
    
    # plot <- ggcorrplot(Q_mat, lab = TRUE, outline.col = "white", digits = 2,
    #                    ggtheme = ggplot2::theme_gray, tl.srt = 75, lab_size = 2.5,
    #                    colors = c("#6D9EC1", "white", "#E46726"),
    #                    legend.title = "Yule's Q")
    # print(plot)
  }
  
  
  return(df)
}
#----------------------------------------------------------------

# Settings for printing plots
ww = 8
wh = (2/3)*8

# Importing all four data sets. Additionally, the variable `Unique.Visits` must
#  be a vector of characters to join later, so it is coerced into a character
#  each time just in case. 
PreVisitData <- read_csv("1 Raw Data//PreVisitData.csv", 
                         col_types = cols(.default = "?", Unique.Visit = "c"))

VisitData <- read_csv("1 Raw Data//VisitData.csv", 
                      col_types = cols(.default = "?", Unique.Visit = "c")) 

PostVisitData <- read_csv("1 Raw Data//PostVisitData.csv", 
                          col_types = cols(.default = "?", Unique.Visit = "c"))

PCRData <- read_csv("1 Raw Data//PCR_Data.csv", 
                    col_types = cols(.default = "?", Unique.Visit = "c"))


# Create a new data frame. The new tbl start equal to PCRData, but is left
#  joined to each of the three other sets, using `Unique.Visit` as a unique 
#  identifier to insure the correct rows are matched together.
FluData <- PCRData %>% 
  left_join(x = .,
            y = PreVisitData,
            by = "Unique.Visit") %>% 
  left_join(x = .,
            y = VisitData,
            by = "Unique.Visit") %>% 
  left_join(x = .,
            y = PostVisitData,
            by = "Unique.Visit")


# Now that the data has been joined together by unique identifiers, we can
# start creating aggregate variables and cleaning up the data frame.

# Create logical variables for all of the symptoms.
PtQ_reported_symptoms <- FluData %$%
  tibble(
    Abd_pain = PtQ.URI.AbdPain == "Yes",
    Adenopathy = PtQ.URI.Adenopathy == "Yes",
    Hearing_loss = PtQ.URI.CantHear == "Yes",
    Chest_congestion = PtQ.URI.ChestCongestion == "Yes",
    Chest_pain = PtQ.URI.ChestPain == "Yes",
    Chills_sweats = PtQ.URI.ChillsSweats == "Yes",
    Congestion = PtQ.URI.Congested == "Yes",
    Cough = PtQ.URI.Cough == "Yes",
    Diarrhea = PtQ.URI.Diarrhea == "Yes",
    Eye_pain = PtQ.URI.EyePn == "Yes",
    Fatigue = PtQ.URI.FAtigue == "Yes",
    Fever = PtQ.URI.Fever == "Yes",
    Headache = PtQ.URI.HA == "Yes",
    Insomnia = PtQ.URI.Insomnia == "Yes",
    Asthenia = PtQ.URI.Intensity.Asthenia != "None",
    Myalgia = PtQ.URI.Intensity.Myalgia != "None",
    Itchy_eye = PtQ.URI.ItchyEye == "Yes",
    Nausea = PtQ.URI.Nausea == "Yes",
    Otalgia = PtQ.URI.Otalgia == "Yes",
    Pharyngitis = PtQ.URI.Pharyngitis == "Yes",
    Rhinorrhea = PtQ.URI.Rhinorrhea == "Yes",
    Shortness_of_breath = PtQ.URI.SOB == "Yes",
    Sneeze = PtQ.URI.Sneeze == "Yes",
    Tooth_pain = PtQ.URI.ToothPn == "Yes",
    Vision_change = PtQ.URI.Vision == "Yes",
    Vomiting = PtQ.URI.Vomit == "Yes",
    Wheezing = PtQ.URI.Wheeze == "Yes"
  ) 


# Calculation of total symptom score without accounting for correlation.
FluData %<>%
  mutate(
    PtQ_total_symptom_score_raw = rowSums(PtQ_reported_symptoms)
  )

# Remove all symptoms which do not have more than 5% variation.
Variation_in_symptoms <- colSums(PtQ_reported_symptoms, na.rm = TRUE)/nrow(PtQ_reported_symptoms) 
Symptoms_sufficient_variation <- Variation_in_symptoms[-which(Variation_in_symptoms <= 0.05 | Variation_in_symptoms >= 0.95)]

# Update PtQ_reported_symptoms to only include variables with at least 5% variation.
PtQ_clean_symptoms <- PtQ_reported_symptoms[,names(Symptoms_sufficient_variation)]

# Remove variables that are more than 90% correlated using method from above.
PtQ_reduced_symptoms <- compare_cor(PtQ_clean_symptoms)

# Calculation of reduced total symptom score.
FluData %<>%
  mutate(
    PtQ_total_symptom_score = rowSums(PtQ_reduced_symptoms)
  )


# Score calculations for visit data.

# Select symptoms recored during the visit
# Now we will do the symptom scores for the Hx variables.
Hx_reported_symptoms <- FluData %$%
  tibble(Resp.Hx.AbdPain, Resp.Hx.CCong, Resp.Hx.CP, 
         Resp.Hx.Chills, Resp.Hx.Diarrhea, Resp.Hx.Earpain,
         Resp.Hx.Emesis, Resp.Hx.Eyeirritation, Resp.Hx.Facepain, 
         Resp.Hx.Fatigue, Resp.Hx.Fever, Resp.Hx.HA, Resp.Hx.JP, 
         Resp.Hx.Myalgias, Resp.Hx.NasalDC, Resp.Hx.Nasalcongestion, 
         Resp.Hx.Nausea, Resp.Hx.PND, Resp.Hx.Retroorbitalpain, 
         Resp.Hx.SOB, Resp.Hx.Sneeze, Resp.Hx.Sorethroat, 
         Resp.Hx.Sputum, Resp.Hx.SubStBurn, Resp.Hx.Swollennodes, 
         Resp.Hx.VoiceLoss, Resp.Hx.Wheeze, Resp.Hx.cough, 
         Resp.Hx.sinuspressure)

# Physicians did not have to provide responces for every symptom.
# If the symptom was left blank the symptom is considered "not reported" 
Hx_reported_symptoms <- Hx_reported_symptoms %>% replace(is.na(.), "Minus")


# Now we will get the symptoms ready to calculate the scores.
Hx_reported_symptoms <- Hx_reported_symptoms %$%
  tibble(
    Abd_pain = Resp.Hx.AbdPain == "Plus",
    Chest_cong = Resp.Hx.CCong == "Plus",
    Chest_pain = Resp.Hx.CP == "Plus",
    Chills = Resp.Hx.Chills == "Plus",
    Diarrhea = Resp.Hx.Diarrhea == "Plus",
    Ear_pain = Resp.Hx.Earpain == "Plus",
    Vomiting = Resp.Hx.Emesis == "Plus",
    Eye_irr = Resp.Hx.Eyeirritation == "Plus",
    Face_pain = Resp.Hx.Facepain == "Plus",
    Fatigue = Resp.Hx.Fatigue == "Plus",
    Fever = Resp.Hx.Fever == "Plus",
    Headache = Resp.Hx.HA == "Plus",
    Joint_pain = Resp.Hx.JP == "Plus",
    Myalgia = Resp.Hx.Myalgias == "Plus",
    Nasal_dc = Resp.Hx.NasalDC == "Plus",
    Nasal_cong = Resp.Hx.Nasalcongestion == "Plus",
    Nausea = Resp.Hx.Nausea == "Plus",
    PND = Resp.Hx.PND == "Plus",
    Eye_pain = Resp.Hx.Retroorbitalpain == "Plus",
    Shortness_of_breath = Resp.Hx.SOB == "Plus",
    Sneeze = Resp.Hx.Sneeze == "Plus",
    Sore_throat = Resp.Hx.Sorethroat == "Plus",
    Sputum = Resp.Hx.Sputum == "Plus",
    Subst_burn = Resp.Hx.SubStBurn == "Plus",
    Adenopathy = Resp.Hx.Swollennodes == "Plus",
    Voice_loss = Resp.Hx.VoiceLoss == "Plus",
    Wheezing = Resp.Hx.Wheeze == "Plus",
    Cough = Resp.Hx.cough == "Plus",
    Sinus_pressure = Resp.Hx.sinuspressure == "Plus"
  )


# Total symptom score NOT accounting for correlations
FluData %<>%
  mutate(
    Hx_total_symptom_score_raw = rowSums(Hx_reported_symptoms)
  )


# Remove all symptoms which do not have more than 5% variation.
Variation_in_symptoms <- colSums(Hx_reported_symptoms, na.rm = TRUE)/nrow(Hx_reported_symptoms) 
Symptoms_sufficient_variation <- Variation_in_symptoms[-which(Variation_in_symptoms <= 0.05 | Variation_in_symptoms >= 0.95)]

# Update Hx_reported_symptoms to only include variables with at least 5% variation.
Hx_clean_symptoms <- Hx_reported_symptoms[,names(Symptoms_sufficient_variation)]

# Remove variables that are more than 90% correlated using method from above.
Hx_reduced_symptoms <- compare_cor(Hx_clean_symptoms)

# Reduced total symptom score accounting for correlations
FluData %<>%
  mutate(
    Hx_total_symptom_score = rowSums(Hx_reduced_symptoms)
  )

# Create a column for the relative viral load using the formula we know,
# as well as extract the Lot Number from the serial number of each tube.
FluData %<>% 
  mutate(RVL = log10(ViralLoad),
         VaccineStatus = forcats::fct_recode(PtQ.URI.AnnualFluShotPtEntered, yes = "|yes|", no = "|no|"))

# Transform Resp.Hx.Onset.Duration variable to integer value prior to plotting.
FluData$Resp.Hx.Onset.Duration[which(FluData$Resp.Hx.Onset.Duration == "4-5 d")] <- 4.5
FluData$Resp.Hx.Onset.Duration[which(FluData$Resp.Hx.Onset.Duration == "2-3 d")] <- 2.5
FluData$Resp.Hx.Onset.Duration <- as.numeric(FluData$Resp.Hx.Onset.Duration)

# Rename the cols of PtQ and Hx symptoms so they are distinct.
names(PtQ_reported_symptoms) <- paste("PtQ", names(PtQ_reported_symptoms), sep = "_")
names(Hx_reported_symptoms) <- paste("Hx", names(Hx_reported_symptoms), sep = "_")

# Clean up the factor levels so that instead of TRUE and FALSE it is Reported and Not reported.

## Clean up PtQ symptoms 
PtQ_reported_symptoms<-data.frame(apply(PtQ_reported_symptoms, 2, factor, 
                                       levels=c("TRUE","FALSE"), 
                                       labels = c("Present", "Not reported")))

## Set Reported as the reference group
relev <- function(f) relevel(factor(f), ref = "Present")
PtQ_reported_symptoms <- mutate_all(PtQ_reported_symptoms, list(relev))

## Clean up Hx symptoms 
Hx_reported_symptoms<-data.frame(apply(Hx_reported_symptoms, 2, factor, 
                                      levels=c("TRUE","FALSE"), 
                                      labels = c("Present", "Not reported")))


## Set Reported as the reference group
relev <- function(f) relevel(factor(f), ref = "Present")
Hx_reported_symptoms <- mutate_all(Hx_reported_symptoms, list(relev))



# Now I need to select the columns to keep.

FinalData <-
  cbind(
    FluData %>%
    select(Flu.A.1, ViralLoad, IC.1, Unique.Visit, PtQ.URI.24ActivityImpact, Sex, Age,
           PtQ.URI.SxEvolutionTime, VaccineStatus, PtQ.URI.Intensity.Asthenia,
           PtQ.URI.Intensity.Cough, PtQ.URI.Intensity.Myalgia, 
           Resp.Hx.Onset.Duration, Q3, Q5, Q6, Temperature = temp1, RVL, 
           PtQ_total_symptom_score, PtQ_total_symptom_score_raw,
           Hx_total_symptom_score, Hx_total_symptom_score_raw),
    PtQ_reported_symptoms,
    Hx_reported_symptoms)

# Now let's make sure all the variables are the correct format.
#str(FinalData)
FinalData %<>%
  mutate(
    Flu.A.1 = as.factor(Flu.A.1),
    IC.1 = as.factor(IC.1),
    Sex = as.factor(Sex),
    PtQ.URI.SxEvolutionTime = fct_relevel(fct_recode(PtQ.URI.SxEvolutionTime, "1-2" = "1-2 d"), "0-1", "1-2", "3+"),
    VaccineStatus = fct_recode(VaccineStatus, "Yes" = "yes", "No" = "no"),
    PtQ.URI.Intensity.Asthenia = fct_relevel(PtQ.URI.Intensity.Asthenia, "None", "Mild", "Moderate", "Severe"),
    PtQ.URI.Intensity.Cough = fct_relevel(PtQ.URI.Intensity.Cough, "None", "Mild", "Moderate", "Severe"),
    PtQ.URI.Intensity.Myalgia = fct_relevel(PtQ.URI.Intensity.Myalgia, "None", "Mild", "Moderate", "Severe"),
    Q5 = fct_relevel(as.factor(Q5), "I did not have a cough", "No improvement", "Improved somewhat", "Improved dramatically"),
    Q3 = factor(Q3, ordered = TRUE)
  )
#str(FinalData)

# Exporting data sets of just the symptom variables to make reporting results easier.
# Symptoms from the patients 
saveRDS(PtQ_reported_symptoms, file = "2 Clean Data/PtQsymptoms.Rda")

# Symptoms from the physicians 
saveRDS(Hx_reported_symptoms, file = "2 Clean Data/Hxsymptoms.Rda")


# Finally export the complete final data.
write.csv(FinalData, file = "2 Clean Data/CleanPCRData.csv")
saveRDS(FinalData, file = "2 Clean Data/CleanPCRData.Rda")

# end of script