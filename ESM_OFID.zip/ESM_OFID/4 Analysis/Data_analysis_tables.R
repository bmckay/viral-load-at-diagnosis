# EDA for Roche Flu Study: Tables
# Author: Zane Billings
# Updated: 06 July, 2019
#
# This script will perform exploratory data analysis on the merged Influenza A
#  positive dataset. All tables generated are contained in this script.

#Clean up global enviroment
rm(list=ls())
#Remove any packages that might have conflicts with the required packages
if(!is.null(names(sessionInfo()$otherPkgs))){
  lapply(paste('package:',names(sessionInfo()$otherPkgs),sep=""),detach,character.only=TRUE,unload=TRUE)}

# Load libaries
if (require('tableone')==FALSE) {install.packages('tableone', repos="https://cran.rstudio.com"); require(tableone)}
if (require('magrittr')==FALSE) {install.packages('magrittr', repos="https://cran.rstudio.com"); require(magrittr)}
if (require('tidyr')==FALSE) {install.packages('tidyr', repos="https://cran.rstudio.com"); require(tidyr)}
if (require('dplyr')==FALSE) {install.packages('dplyr', repos="https://cran.rstudio.com"); require(dplyr)}

# Import data.
FluData <- readRDS("2 Clean Data/CleanPCRData.Rda")


#===============================================================================
# These are the three tables for each of the data collection points.  
# 1. Pre-vist
# 2. During-Visit
# 3. Post-visit
#===============================================================================
#-------------------------------------------------------------------------------
# Pre-visit data
Table_previsit_data <-
  FluData %>% 
  select(
    "Patient sex" = Sex,
    "Patient age" = Age,
    "Activity level" = PtQ.URI.24ActivityImpact,
    "Days since onset" = PtQ.URI.SxEvolutionTime,
    "Intensity of aches and pains" = PtQ.URI.Intensity.Myalgia,
    "Intensity of cough" = PtQ.URI.Intensity.Cough,
    "Intensity of weakness" = PtQ.URI.Intensity.Asthenia,
    "Abdominal pain" = PtQ_Abd_pain,
    "Cough" = PtQ_Cough,
    "Chest congestion" = PtQ_Chest_congestion,
    "Chest pain" = PtQ_Chest_pain,
    "Chills sweats" = PtQ_Chills_sweats,
    "Diarrhea" = PtQ_Diarrhea,
    "Ear pain" = PtQ_Otalgia,
    "Eye pain" = PtQ_Eye_pain,
    "Fatigue" = PtQ_Fatigue,
    "Hearing loss" = PtQ_Hearing_loss,
    "Headache" = PtQ_Headache,
    "Insomnia" = PtQ_Insomnia,
    "Itchy eye" = PtQ_Itchy_eye,
    "Nasal congestion" = PtQ_Congestion,
    "Nausea" = PtQ_Nausea,
    "Myalgia" = PtQ_Myalgia,
    "Runny nose" = PtQ_Rhinorrhea,
    "Sore throat" = PtQ_Pharyngitis,
    "Shortness of breath" =  PtQ_Shortness_of_breath,
    "Sneeze" = PtQ_Sneeze,
    "Subjective fever" = PtQ_Fever,
    "Swollen lymph nodes" = PtQ_Adenopathy,
    "Tooth pain" = PtQ_Tooth_pain,
    "Vomiting" = PtQ_Vomiting,
    "Vision change" = PtQ_Vision_change,
    "Weakness" = PtQ_Asthenia,
    "Wheezing" = PtQ_Wheezing
  ) %>% 
  tidyr::drop_na() %>% 
  CreateTableOne(data = .) %>% 
  print(., showAllLevels = TRUE)

saveRDS(Table_previsit_data, "5 Results/Tables/Table_previsit_data.Rda")


#-------------------------------------------------------------------------------
# Visit Data
Table_visitsummary <-
  FluData %>% 
  select(
    "Patient sex" = Sex,
    "Patient age" = Age,
    "Patient temperature" = Temperature,
    "Days since onset of symptoms" = Resp.Hx.Onset.Duration,
    "Abdominal pain"= Hx_Abd_pain,
    "Cough" = Hx_Cough,
    "Chest congestion" = Hx_Chest_cong,
    "Chest pain" = Hx_Chest_pain,
    "Chills" = Hx_Chills,
    "Diarrhea" = Hx_Diarrhea,
    "Ear Pain" = Hx_Ear_pain,
    "Eye pain" = Hx_Eye_pain,
    "Vomiting" = Hx_Vomiting,
    "Eye irritation" = Hx_Eye_irr,
    "Face pain" = Hx_Face_pain,
    "Fatigue" = Hx_Fatigue,
    "Fever" = Hx_Fever,
    "Headache" = Hx_Headache,
    "Joint pain" = Hx_Joint_pain,
    "Myalgia" = Hx_Myalgia,
    "Nasal discharge" = Hx_Nasal_dc,
    "Nasal congestion" = Hx_Nasal_cong,
    "Nausea" = Hx_Nausea,
    "Post-nasal drip" = Hx_PND,
    "Sinus pressure" = Hx_Sinus_pressure,
    "Shortness of breath" = Hx_Shortness_of_breath,
    "Sore throat" = Hx_Sore_throat,
    "Sneezing" = Hx_Sneeze,
    "Sputum" = Hx_Sputum,
    "Substernal burning" = Hx_Subst_burn,
    "Swollen lymph nodes" = Hx_Adenopathy,
    "Voice loss" = Hx_Voice_loss,
    "Wheezing" = Hx_Wheezing
  ) %>% 
  CreateTableOne(data = .) %>% 
  print(., showAllLevels = TRUE)

saveRDS(Table_visitsummary, "5 Results/Tables/Table_visit_data.Rda")
#-------------------------------------------------------------------------------
# post Visit Data
# need Q3 to be numeric for this table 
FluData$Q3<-as.numeric(FluData$Q3)
Table_postvisitdata <-
  FluData %>% 
  select(
    "Patient sex" = Sex,
    "Patient age" = Age,
    "Days of work/class missed" = Q3,
    "Days fever was present after visit" = Q6,
    "Recovery from cough in 5 days" = Q5
  )  %>% 
  drop_na() %>% 
  CreateTableOne(data = .) %>% 
  print(., showAllLevels = TRUE)

saveRDS(Table_postvisitdata, "5 Results/Tables/Table_postvisit_data.Rda")
#-------------------------------------------------------------------------------
#===============================================================================
# These are additional tables (likely in SM) 
# 1. total symptom scores for PtQ and Hx
# 2. RVL (log10) and RVL 
# 3. Info about machines used
#===============================================================================

#-------------------------------------------------------------------------------
# Viral load info
Table_viralload <-
  FluData %>% 
  select("Relative log10 viral load" = RVL,
         "Relative viral load" = ViralLoad) %>% 
  CreateTableOne(data = .) %>% 
  print(.)

saveRDS(Table_viralload, "5 Results/Tables/Table_viralload.Rda")
#-------------------------------------------------------------------------------
