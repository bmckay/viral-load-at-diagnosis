# Models
# Author: Zane Billings, Brian McKay
# Updated: 21 September, 2020
#
# This script produces all statistical models.


#Clean up global enviroment
rm(list=ls())
#Remove any packages that might have conflicts with the required packages
if(!is.null(names(sessionInfo()$otherPkgs))){
  lapply(paste('package:',names(sessionInfo()$otherPkgs),sep=""),detach,character.only=TRUE,unload=TRUE)}

# Load libaries
if (require('dplyr')==FALSE) {install.packages('dplyr', repos="https://cran.rstudio.com"); require(dplyr)}
if (require('vcdExtra')==FALSE) {install.packages('vcdExtra', repos="https://cran.rstudio.com"); require(vcdExtra)}
if (require('DescTools')==FALSE) {install.packages('DescTools', repos="https://cran.rstudio.com"); require(DescTools)}

# Import Data. Unique.Vist needs to be imported as a character.
FluData <- readRDS("2 Clean Data/CleanPCRData.Rda")


#===============================================================================
# Symptom score linear models:
# - RVL vs PtQ total score REDUCED 
# - RVL vs PtQ total score RAW
# - RVL vs Hx scores REDUCED
# - RVL vs Hx scores RAW
#===============================================================================
#-------------------------------------------------------------------------------
# RVL vs. PtQ total score REDUCED
Model_RVL_vs_PtQ_total_score <-
  lm(PtQ_total_symptom_score~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_PtQ_total_score,
        file = "5 Results/Models/RVL_vs_PtQ_total_score.Rda")

Rho_RVL_vs_PtQ_total_score <- SpearmanRho(FluData$PtQ_total_symptom_score, 
                                          FluData$RVL, use=c("complete.obs"), 
                                          conf.level = 0.95)

saveRDS(Rho_RVL_vs_PtQ_total_score, 
        file = "5 Results/Models/Rho_RVL_vs_PtQ_total_score.Rda")

P_Rho_RVL_vs_PtQ_total_score <-cor.test(FluData$PtQ_total_symptom_score, 
                                       FluData$RVL, method = "spearman",
                                       continuity = FALSE,
                                       conf.level = 0.95)

saveRDS(P_Rho_RVL_vs_PtQ_total_score, 
        file = "5 Results/Models/P_Rho_RVL_vs_PtQ_total_score.Rda")

#-------------------------------------------------------------------------------
# RVL vs. PtQ total score RAW
Model_RVL_vs_PtQ_total_score_raw <-
  lm(PtQ_total_symptom_score_raw~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_PtQ_total_score_raw,
        file = "5 Results/Models/RVL_vs_PtQ_total_score_raw.Rda")

# adding duration 
Model_RVL_Duration_vs_PtQ_total_score_raw <-
  lm(PtQ_total_symptom_score_raw~RVL+Resp.Hx.Onset.Duration,
     data = FluData)

saveRDS(object = Model_RVL_Duration_vs_PtQ_total_score_raw,
        file = "5 Results/Models/RVL_Duration_vs_PtQ_total_score_raw.Rda")


Rho_RVL_vs_PtQ_total_score_raw <- SpearmanRho(FluData$PtQ_total_symptom_score_raw, 
                                              FluData$RVL, use=c("complete.obs"), 
                                              conf.level = 0.95)
saveRDS(Rho_RVL_vs_PtQ_total_score_raw, 
        file = "5 Results/Models/Rho_RVL_vs_PtQ_total_score_raw.Rda")

P_Rho_RVL_vs_PtQ_total_score_raw <- cor.test(FluData$PtQ_total_symptom_score_raw, 
                                              FluData$RVL,  method = "spearman",
                                             continuity = FALSE,
                                             conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_PtQ_total_score_raw, 
        file = "5 Results/Models/P_Rho_RVL_vs_PtQ_total_score_raw.Rda")

#-------------------------------------------------------------------------------
# RVL vs. hx total score REDUCED 
Model_RVL_vs_Hx_total_score <-
  lm(Hx_total_symptom_score~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_Hx_total_score,
        file = "5 Results/Models/RVL_vs_Hx_total_score.Rda")

Rho_RVL_vs_Hx_total_score <- SpearmanRho(FluData$Hx_total_symptom_score, 
                                         FluData$RVL, use=c("complete.obs"), 
                                         conf.level = 0.95)
saveRDS(Rho_RVL_vs_Hx_total_score, 
        file = "5 Results/Models/Rho_RVL_vs_Hx_total_score.Rda")

P_Rho_RVL_vs_Hx_total_score <- cor.test(FluData$Hx_total_symptom_score, 
                                         FluData$RVL,  method = "spearman",
                                         continuity = FALSE,
                                         conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_Hx_total_score, 
        file = "5 Results/Models/P_Rho_RVL_vs_Hx_total_score.Rda")

#-------------------------------------------------------------------------------
# RVL vs. hx total score RAW
Model_RVL_vs_Hx_total_score_raw <-
  lm(Hx_total_symptom_score_raw~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_Hx_total_score_raw,
        file = "5 Results/Models/RVL_vs_Hx_total_score_raw.Rda")

# adding duration 
Model_RVL_Duration_vs_Hx_total_score_raw <-
  lm(Hx_total_symptom_score_raw~RVL+Resp.Hx.Onset.Duration,
     data = FluData)

saveRDS(object = Model_RVL_Duration_vs_Hx_total_score_raw,
        file = "5 Results/Models/RVL_Duration_vs_Hx_total_score_raw.Rda")


Rho_RVL_vs_Hx_total_score_raw <- SpearmanRho(FluData$Hx_total_symptom_score_raw, 
                                             FluData$RVL, use=c("complete.obs"), 
                                             conf.level = 0.95)
saveRDS(Rho_RVL_vs_Hx_total_score_raw, 
        file = "5 Results/Models/Rho_RVL_vs_Hx_total_score_raw.Rda")

P_Rho_RVL_vs_Hx_total_score_raw <- cor.test(FluData$Hx_total_symptom_score_raw, 
                                             FluData$RVL, method = "spearman",
                                            continuity = FALSE,
                                            conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_Hx_total_score_raw, 
        file = "5 Results/Models/P_Rho_RVL_vs_Hx_total_score_raw.Rda")

#-------------------------------------------------------------------------------
# correlation between patient and physician symptom scores

Rho_PtQ_vs_Hx_total_score_raw <- SpearmanRho(FluData$Hx_total_symptom_score_raw, 
                                         FluData$PtQ_total_symptom_score_raw, use=c("complete.obs"), 
                                         conf.level = 0.95)
saveRDS(Rho_PtQ_vs_Hx_total_score_raw, 
        file = "5 Results/Models/Rho_PtQ_vs_Hx_total_score_raw.Rda")

P_Rho_PtQ_vs_Hx_total_score_raw <- cor.test(FluData$Hx_total_symptom_score_raw, 
                                        FluData$PtQ_total_symptom_score_raw,  method = "spearman",
                                        continuity = FALSE,
                                        conf.level = 0.95)
saveRDS(P_Rho_PtQ_vs_Hx_total_score_raw, 
        file = "5 Results/Models/P_Rho_PtQ_vs_Hx_total_score_raw.Rda")

#===============================================================================
# "Predictive" models
# - RVL vs days work missed
# - RVL vs cough recovery
# - RVL vs fever recovery
#===============================================================================
#-------------------------------------------------------------------------------
# RVL vs. days of work/class missed LM
Model_RVL_vs_days_missed <-
  lm(as.numeric(as.character(FluData$Q3))~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_days_missed,
        file = "5 Results/Models/RVL_vs_days_missed.Rda")

Rho_RVL_vs_days_missed <- SpearmanRho(as.numeric(as.character(FluData$Q3)), 
                                      FluData$RVL, use=c("complete.obs"), 
                                      conf.level = 0.95)
saveRDS(Rho_RVL_vs_days_missed, 
        file = "5 Results/Models/Rho_RVL_vs_days_missed.Rda")


P_Rho_RVL_vs_days_missed <- cor.test(as.numeric(as.character(FluData$Q3)), 
                                      FluData$RVL, method = "spearman",
                                      continuity = FALSE,
                                      conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_days_missed, 
        file = "5 Results/Models/P_Rho_RVL_vs_days_missed.Rda")


#-------------------------------------------------------------------------------
# RVL vs cough recovery LM
Model_RVL_vs_cough_recovery <-
  lm(as.numeric(Q5)~RVL,
          data = filter(FluData,Q5!="I did not have a cough"))

saveRDS(object = Model_RVL_vs_cough_recovery,
        file = "5 Results/Models/RVL_vs_cough_recovery.Rda")

Rho_RVL_vs_cough_recovery <- SpearmanRho(as.numeric(FluData$Q5), 
                                         FluData$RVL, use=c("complete.obs"), 
                                         conf.level = 0.95)
saveRDS(Rho_RVL_vs_cough_recovery, 
        file = "5 Results/Models/Rho_RVL_vs_cough_recovery.Rda")


P_Rho_RVL_vs_cough_recovery <- cor.test(as.numeric(FluData$Q5), 
                                         FluData$RVL, method = "spearman",
                                         continuity = FALSE,
                                         conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_cough_recovery, 
        file = "5 Results/Models/P_Rho_RVL_vs_cough_recovery.Rda")


#-------------------------------------------------------------------------------
# RVL vs fever recovery LM
Model_RVL_vs_fever_recovery <-
  lm(Q6~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_fever_recovery,
        file = "5 Results/Models/RVL_vs_fever_recovery.Rda")

Rho_RVL_vs_fever_recovery <- SpearmanRho(FluData$Q6, 
                                         FluData$RVL, use=c("complete.obs"), 
                                         conf.level = 0.95)
saveRDS(Rho_RVL_vs_fever_recovery, 
        file = "5 Results/Models/Rho_RVL_vs_fever_recovery.Rda")

P_Rho_RVL_vs_fever_recovery <- cor.test(FluData$Q6, 
                                         FluData$RVL, method = "spearman",
                                         continuity = FALSE,
                                         conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_fever_recovery, 
        file = "5 Results/Models/P_Rho_RVL_vs_fever_recovery.Rda")

#-------------------------------------------------------------------------------
#===============================================================================
# All other RVL models
# - RVL vs. activity level (F test and spearman)
# - RVL vs. symptom duration (F test and spearman) 
# - RVL vs. temperature (F test and spearman)
# - RVL vs. subjective fever (t test and spearman)

#===============================================================================
#-------------------------------------------------------------------------------
# RVL vs activity level
Model_RVL_vs_activity <-
  lm(PtQ.URI.24ActivityImpact~RVL,
          data = FluData)

saveRDS(object = Model_RVL_vs_activity,
        file = "5 Results/Models/RVL_vs_activity.Rda")

Rho_RVL_vs_activity <- SpearmanRho(FluData$PtQ.URI.24ActivityImpact, 
                                   FluData$RVL, use=c("complete.obs"), 
                                   conf.level = 0.95)
saveRDS(Rho_RVL_vs_activity, 
        file = "5 Results/Models/Rho_RVL_vs_activity.Rda")

P_Rho_RVL_vs_activity <- cor.test(FluData$PtQ.URI.24ActivityImpact, 
                                   FluData$RVL, method = "spearman",
                                   continuity = FALSE,
                                   conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_activity, 
        file = "5 Results/Models/P_Rho_RVL_vs_activity.Rda")

#-------------------------------------------------------------------------------
#  RVL vs. the onset/duration of symptoms
Model_RVL_vs_symptom_duration_lm <- 
  lm(formula = Resp.Hx.Onset.Duration~RVL, 
     data = FluData)

saveRDS(object = Model_RVL_vs_symptom_duration_lm,
        file = "5 Results/Models/RVL_vs_symptom_duration_lm.Rda")

Rho_RVL_vs_symptom_duration <- SpearmanRho(FluData$Resp.Hx.Onset.Duration, 
                                           FluData$RVL, use=c("complete.obs"), 
                                           conf.level = 0.95)
saveRDS(Rho_RVL_vs_symptom_duration, 
        file = "5 Results/Models/Rho_RVL_vs_symptom_duration.Rda")


P_Rho_RVL_vs_symptom_duration <- cor.test(FluData$Resp.Hx.Onset.Duration, 
                                           FluData$RVL, method = "spearman",
                                           continuity = FALSE,
                                           conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_symptom_duration, 
        file = "5 Results/Models/P_Rho_RVL_vs_symptom_duration.Rda")


#-------------------------------------------------------------------------------
# RVL vs. Body temperature
Model_RVL_vs_temp <- 
  lm(Temperature~RVL,
     data = FluData)

saveRDS(object = Model_RVL_vs_temp,
        file = "5 Results/Models/RVL_vs_temp.Rda")

Rho_RVL_vs_temp <- SpearmanRho(FluData$Temperature, 
                               FluData$RVL, use=c("complete.obs"), 
                               conf.level = 0.95)
saveRDS(Rho_RVL_vs_temp, 
        file = "5 Results/Models/Rho_RVL_vs_temp.Rda")

P_Rho_RVL_vs_temp <- cor.test(FluData$Temperature, 
                               FluData$RVL, method = "spearman",
                              continuity = FALSE,
                              conf.level = 0.95)
saveRDS(P_Rho_RVL_vs_temp, 
        file = "5 Results/Models/P_Rho_RVL_vs_temp.Rda")

#===============================================================================
# Symptom severity models:
# - RVL vs asthenia severity.
# - RVL vs cough severity.
# - RVL vs myalgia severity.
#===============================================================================
#-------------------------------------------------------------------------------
# RVL vs severity of asthenia
Model_RVL_vs_asthenia_severity <-
  lm(RVL~PtQ.URI.Intensity.Asthenia,
     data = FluData) 

saveRDS(object = Model_RVL_vs_asthenia_severity,
        file = "5 Results/Models/RVL_vs_asthenia_severity.Rda")
#-------------------------------------------------------------------------------
# RVL vs severity of cough
Model_RVL_vs_cough_severity <-
  lm(RVL~PtQ.URI.Intensity.Cough,
     data = FluData)  

saveRDS(object = Model_RVL_vs_cough_severity,
        file = "5 Results/Models/RVL_vs_cough_severity.Rda")
#-------------------------------------------------------------------------------
# RVL vs severity of myalgia
Model_RVL_vs_myalgia_severity <-
  lm(RVL~PtQ.URI.Intensity.Myalgia,
     data = FluData) 

saveRDS(object = Model_RVL_vs_myalgia_severity,
        file = "5 Results/Models/RVL_vs_myalgia_severity.Rda")
#-------------------------------------------------------------------------------


## This is the end of the script.
