# EDA for Roche Flu Study: Plots.
# Author: Zane Billings, Brian McKay
# Updated: 18 September, 2020
#
# All plots generated are contained in this script.

#Clean up global enviroment
rm(list=ls())

#Remove any packages that might have conflicts with the required packages
if(!is.null(names(sessionInfo()$otherPkgs))){
  lapply(paste('package:',names(sessionInfo()$otherPkgs),sep=""),detach,character.only=TRUE,unload=TRUE)}

# Load libaries
if (require('tidyverse')==FALSE) {install.packages('tidyverse', repos="https://cran.rstudio.com"); require(tidyverse)}
if (require('magrittr')==FALSE) {install.packages('magrittr', repos="https://cran.rstudio.com"); require(magrittr)}
if (require('gridExtra')==FALSE) {install.packages('gridExtra', repos="https://cran.rstudio.com"); require(gridExtra)}


# Import Data
FluData <- readRDS("2 Clean Data/CleanPCRData.Rda")

# Window dimensions for exporting graphics
ww <- 8
wh <- (2/3) * ww

# plot window size
windows(width=ww, height=wh)

# Theme for graphics
manuscriptTheme <- theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5), 
                         plot.subtitle = element_text(size = 14),
                         axis.title.x = element_text(size = 16),
                         axis.title.y = element_text(size = 16),
                         axis.text = element_text(size = 14),
                         legend.position = "none",
                         panel.background = element_rect(fill = "white", color = "black"),
                         panel.grid.major = element_blank(),
                         panel.grid.minor = element_blank())

#===============================================================================
#This section of the code will look at the differences in several potentially
#clinically relevant variables based on the influenza A relative viral load.
#===============================================================================

#-----------------------------------
# Plots for main text
#-----------------------------------


# RVL vs 24 hour activity impact

FluData %>% 
  drop_na(PtQ.URI.24ActivityImpact) %>% 
  ggplot(aes(y = PtQ.URI.24ActivityImpact, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  labs(y = "Patient reported activity level",
       x = expression(paste("Relative Viral Load (", log[10], ")"))) +
  scale_y_continuous(breaks=0:10, labels=seq(0,10,by=1)) +
  manuscriptTheme

dev.print(device = tiff, width = ww, height = wh, units = "in",
          filename = "5 Results/Figures/Viral_load/RVL_vs_pt_reported_limited_activity.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)

#-------------------------------------------------------------------------------
# PtQ total score RAW and RVL
A1<-FluData %>% 
  select(PtQ_total_symptom_score_raw, RVL) %>% 
  drop_na() %>% 
  ggplot(aes(y = PtQ_total_symptom_score_raw, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  manuscriptTheme

A1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_PtQ_total_score_raw.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Hx total score RAW and RVL 
B1<-FluData %>% 
  select(Hx_total_symptom_score_raw, RVL) %>% 
  drop_na() %>% 
  ggplot(aes(y = Hx_total_symptom_score_raw, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  manuscriptTheme
B1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_Hx_total_score_raw.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# RVL vs. total symptom scores RAW (Hx and PtQ).

# Make a combined figure
pA<-A1+labs(y = "Patient Reported Symptoms", 
            x=expression(paste("Relative Viral Load (", log[10], ")")), tag = "A") + ylim(0, 25)
pB<-B1+labs(y = "Physician Recorded Symptoms", 
            x=expression(paste("Relative Viral Load (", log[10], ")")), tag = "B") + ylim(0, 25)

plotG <- grid.arrange(pA, pB, nrow = 2)

dev.print(device = tiff, width = wh, height = ww, units = "in",
          filename="5 Results/Figures/Viral_load/RVL_vs_total_score_Hx_and_PtQ_raw.tiff",
          pointsize = 12, compression = c("lzw"), res=600)

#-------------------------------------------------------------------------------
# PtQ total score RAW and Hx total score RAW
FluData %>% 
  select(PtQ_total_symptom_score_raw, Hx_total_symptom_score_raw) %>% 
  drop_na() %>% 
  ggplot(aes(y = PtQ_total_symptom_score_raw, x = Hx_total_symptom_score_raw)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  labs(y = "Patient Reported Symptoms",
       x = "Physician Recorded Symptoms")+
  manuscriptTheme


dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/PtQ_vs_Hx_total_score_raw.tiff",
          pointsize = 12, compression = c("lzw"), res=600)



#-------------------------------------------------------------------------------
# Does relative viral load relate to the days of work missed?
#  This question was Q3 on the post-Visit survey.
A1<-FluData %>% 
      drop_na(Q3) %>% 
      ggplot(aes(y = Q3, x = RVL)) +
      geom_point(aes(alpha=0.75)) +
      geom_smooth(method = "lm", aes(group = 1)) + 
      labs(y = "Reported days of work or class missed",
           x = expression(paste("Relative Viral Load (", log[10], ")"))) +
      manuscriptTheme

A1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_days_work_missed.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does relative viral load relate to recovery from a fever?
#  This question was Q6 on the post-Visit survey.
B1<-FluData %>% 
  drop_na(Q6) %>% 
  ggplot(aes(y = Q6, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  labs(y = "Days with fever five days after visit",
       x = expression(paste("Relative Viral Load (", log[10], ")"))) +
  manuscriptTheme
B1

dev.print(device = tiff, width = ww, height = wh, units = "in",
          filename = "5 Results/Figures/Viral_load/RVL_vs_fever_recovery.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does relative viral load relate to recovery from cough?
#  This question was Q5 on the post-Visit survey.
#  Before plotting, Q5 variable needed to have appropriate levels set.
C1<-FluData %>% 
      drop_na(Q5) %>%
      filter(Q5!="I did not have a cough") %>%
      ggplot(aes(x = Q5, y = RVL)) +
      #geom_boxplot(width=0.25)+
      geom_point(aes(alpha=.75)) +
      stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, stroke=1.5, col = "red") +
      stat_summary(fun.y = median, geom = "point", shape = 0, size = 3, stroke=1.5, col = "blue") +  
      labs(x = "Improvement of cough five days after visit",
           y = expression(paste("Relative Viral Load (", log[10], ")"))) +
      coord_flip()+
      manuscriptTheme
      
C1

dev.print(device = tiff, width = ww, height = wh, units = "in",
          filename = "5 Results/Figures/Viral_load/RVL_vs_cough_recovery.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)
dev.off()
windows(width=6, height=12)
#-------------------------------------------------------------------------------

# Make a combined figure
pA<-A1+
    labs(y = "Days missed", x=NULL, tag = "A")
pB<-B1+
  labs(y = "Days with fever", x=NULL, tag = "B")

pC<-C1+
    labs(x = "Improvement in Cough", y=expression(paste("Relative Viral Load (", log[10], ")")), tag = "C")+ 
    scale_x_discrete(labels=c("No improvement"="None", 
                              "Improved somewhat" = "Some", 
                              "Improved dramatically" = "Dramatic"))+
    theme(axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.85))



plotG <- grid.arrange(pA, pB, pC, ncol = 1, nrow = 3)


dev.print(device = tiff, width = 6, height = 12, units = "in",
          filename="5 Results/Figures/Viral_load/RVL_vs_FollowUp.tiff",
          pointsize = 12, compression = c("lzw"), res=600)

dev.off()
windows(width=ww, height=wh)
#-------------------------------------------------------------------------------
# Does relative viral load relate to days of symptom duration before visit?
P<-FluData %>% 
  drop_na(Resp.Hx.Onset.Duration) %>% 
  ggplot(aes(y = Resp.Hx.Onset.Duration, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  labs(y = "Time since symptom onset",
       x = expression(paste("Relative Viral Load (", log[10], ")"))) +
  scale_y_continuous(breaks=0:max(FluData$Resp.Hx.Onset.Duration[!is.na(FluData$Resp.Hx.Onset.Duration)])) +
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in",
          filename = "5 Results/Figures/Viral_load/RVL_vs_reported_sx_duration_HX.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------

# Temperature and RVL.
A1<-FluData %>% 
      drop_na(RVL, Temperature) %>% 
      ggplot(aes(y = Temperature, x = RVL)) +
      geom_point(aes(alpha=0.75)) +
      geom_smooth(method = "lm") +
      labs(y = expression(paste("Patient Temperature ("," ", degree ~ F, ")")),
           x = expression(paste("Relative Viral Load (", log[10], ")"))) +
      manuscriptTheme

A1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_temperature.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# RVL vs. subjective fever.
B1<-FluData %>% 
      select(PtQ_Fever, RVL) %>% 
      mutate(fever = fct_recode(as.factor(PtQ_Fever), Yes = "Reported", No = "Not reported")) %>% 
      drop_na() %>% 
      ggplot(aes(x = fever, y = RVL)) +
      geom_violin() +
      geom_boxplot(width = 0.2) +
      stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
      labs(x = "Patient reported fever", y = expression(paste("Relative Viral Load (", log[10], ")"))) +
      coord_flip()+
      manuscriptTheme

B1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_subjective_fever.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# RVL vs. subjective fever and temp.

# Make a combined figure
pA<-A1+labs(x = "Patient temperature (degrees Fahreinheit)", 
                         y=expression(paste("Relative Viral Load (", log[10], ")")), tag = "A")
pB<-B1+labs(x = "Patient reported fever", y=NULL, tag = "B")

plotG <- grid.arrange(pA, pB, ncol = 2, widths=2:1)

dev.print(device = tiff, width = ww, height = wh, units = "in",
          filename="5 Results/Figures/Viral_load/RVL_vs_subjective_fever_and_temp.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# PtQ and Hx total score
FluData %>% 
  select("Clinician reported symptoms" = Hx_total_symptom_score, 
         "Patient reported symptoms" = PtQ_total_symptom_score) %>% 
  gather(key = "Source", value = "Score") %>% 
  drop_na() %>% 
  ggplot(aes(x = Source, y = Score)) +
  geom_violin() +
  geom_boxplot(width = 0.1) +
  stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
  labs(x = "Source of score data", y = "Total symptom score")+
  coord_flip()+
  manuscriptTheme
  

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Scores/Total_symptom_score_distributions.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Total scores and RVL
P<-FluData %>% 
  select(
    "Clinician reported score" = Hx_total_symptom_score, 
    "Patient reported score" = PtQ_total_symptom_score, 
    RVL) %>%
  gather(key = "Source", value = "Score", -RVL) %>% 
  drop_na() %>% 
  ggplot(aes(x = Score, y = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  facet_wrap(~Source) +
  labs(x = "Total symptom score", y = expression(paste("Relative Viral Load (", log[10], ")")))+
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_total_scores.tiff",
          pointsize = 12, compression = c("lzw"), res=600)







#=================================================
# Plots for SM  
# EDA plots
#=================================================

#-------------------------------------------------------------------------------
# PtQ total score and RVL
A1<-FluData %>% 
  select(PtQ_total_symptom_score, RVL) %>% 
  drop_na() %>% 
  ggplot(aes(y = PtQ_total_symptom_score, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  manuscriptTheme

A1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_PtQ_total_score.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Hx total score and RVL 
B1<-FluData %>% 
  select(Hx_total_symptom_score, RVL) %>% 
  drop_na() %>% 
  ggplot(aes(y = Hx_total_symptom_score, x = RVL)) +
  geom_point(aes(alpha=0.75)) +
  geom_smooth(method = "lm") +
  manuscriptTheme
B1

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_Hx_total_score.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# RVL vs. total symptom score (Hx and PtQ).
# Make a combined figure
pA<-A1+labs(y = "Patient Reported Symptoms", 
            x=expression(paste("Relative Viral Load (", log[10], ")")), tag = "A") + ylim(0, 18)
pB<-B1+labs(y = "Physician Recorded Symptoms", x=expression(paste("Relative Viral Load (", log[10], ")")), tag = "B") + ylim(0, 18)

plotG <- grid.arrange(pA, pB, nrow = 2)

dev.print(device = tiff, width = wh, height = ww, units = "in",
          filename="5 Results/Figures/Viral_load/RVL_vs_total_score_Hx_and_PtQ.tiff",
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does reported severity of asthenia (fatigue) relate to relative viral load?
# First, the asthenia severity variable needs to be coerced into order, as 
#  read_csv() will not automatically recognize the order.
P<-FluData %>% 
  drop_na(PtQ.URI.Intensity.Asthenia) %>% 
  ggplot(aes(x = PtQ.URI.Intensity.Asthenia, y = RVL)) +
  geom_violin() +
  geom_boxplot(width = 0.1) +
  stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
  labs(x = "Reported severity of weakness (asthenia)",
       y = expression(paste("Relative Viral Load (", log[10], ")"))) +
  coord_flip()+
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_asthenia_intensity.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does reported severity of cough relate to relative viral load?
# First, the cough severity variable needs to be coerced into order, as 
#  read_csv() will not automatically recognize the order.
P<-FluData %>% 
  drop_na(PtQ.URI.Intensity.Cough) %>% 
  ggplot(aes(x = PtQ.URI.Intensity.Cough, y = RVL)) +
  geom_violin() +
  geom_boxplot(width = 0.1) +
  stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
  labs(x = "Reported severity of cough",
       y = expression(paste("Relative Viral Load (", log[10], ")"))) +
  coord_flip()+
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_cough_intensity.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does reported severity of myalgia relate to relative viral load?
# First, the myalgia severity variable needs to be coerced into order, as 
#  read_csv() will not automatically recognize the order.
P<-FluData %>% 
  drop_na(PtQ.URI.Intensity.Myalgia) %>% 
  ggplot(aes(x = PtQ.URI.Intensity.Myalgia, y = RVL)) + 
  geom_violin() +
  geom_boxplot(width = 0.1) +
  stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
  labs(x = "Reported severity of myalgia",
       y = expression(paste("Relative Viral Load (", log[10], ")"))) +
  theme(plot.title = element_text(hjust = 0.5)) +
  coord_flip()+
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_myalgia_intensity.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)


#-------------------------------------------------------------------------------
# Does reported symptom evolution time relate to relative viral load?
P<-FluData %>% 
  drop_na(PtQ.URI.SxEvolutionTime) %>% 
  ggplot(aes(x = PtQ.URI.SxEvolutionTime, y = RVL)) +
  geom_violin() +
  geom_boxplot(width = 0.1) +
  stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, col = "red") +
  labs(x = "Reported time (in days) since symptom onset",
       y = expression(paste("Relative Viral Load (", log[10], ")"))) +
  coord_flip()+
  manuscriptTheme

P

dev.print(device = tiff, width = ww, height = wh, units = "in", 
          filename = "5 Results/Figures/Viral_load/RVL_vs_symptom_evolution_time.tiff", 
          pointsize = 12, compression = c("lzw"), res=600)

dev.off()
